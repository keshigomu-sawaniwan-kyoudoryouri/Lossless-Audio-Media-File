"""
ripping.py - EAC連携：WAV/FLAC/m4a(ALAC)監視 → LAMF自動変換 → 元ファイル削除
対応形式: .wav, .WAV, .flac, .FLAC, .m4a, .M4A（ただしALACコーデックのみ）
"""

import os
import time
import hashlib
import subprocess
import tempfile
from pathlib import Path

from convert import wav_to_lamf

# ========== 設定 ==========
WATCH_FOLDER = r"D:/LAMFファイル変換"
OUTPUT_FOLDER = r"T:/music/CD_LAMF"
SLEEP_INTERVAL = 2
SUPPORTED_EXTENSIONS = {'.wav', '.WAV', '.flac', '.FLAC', '.m4a', '.M4A'}

# ========== フォルダ準備 ==========
os.makedirs(WATCH_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ========== 処理済み追跡 ==========
processed_hashes = set()
processed_names = set()


def get_file_hash(filepath, chunk_size=8192):
    hash_md5 = hashlib.md5()
    try:
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except Exception:
        return None


def is_file_ready(filepath, wait_seconds=1):
    try:
        size1 = os.path.getsize(filepath)
        time.sleep(wait_seconds)
        size2 = os.path.getsize(filepath)
        return size1 == size2 and size1 > 0
    except Exception:
        return False


def flac_to_wav(flac_path, wav_path):
    """FLAC → WAV変換（ffmpeg使用）"""
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
    except:
        print("   ❌ ffmpegが見つかりません。FLAC対応にはffmpegが必要です")
        return False
    
    cmd = ["ffmpeg", "-i", flac_path, "-acodec", "pcm_s16le", "-y", wav_path]
    result = subprocess.run(cmd, capture_output=True)
    
    return result.returncode == 0 and os.path.exists(wav_path)


def m4a_to_wav(m4a_path, wav_path):
    """m4a(ALAC) → WAV変換（ffmpeg使用）"""
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
    except:
        print("   ❌ ffmpegが見つかりません。m4a対応にはffmpegが必要です")
        return False
    
    # ffprobeでコーデックを確認（ALACチェック）
    probe_cmd = [
        "ffprobe", "-v", "error", "-select_streams", "a:0",
        "-show_entries", "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1",
        m4a_path
    ]
    result = subprocess.run(probe_cmd, capture_output=True, text=True)
    codec = result.stdout.strip().lower()
    
    if codec != "alac":
        print(f"   ⚠ スキップ: {Path(m4a_path).name} はALACではありません（コーデック: {codec}）")
        print(f"   📝 このスクリプトはALAC（可逆圧縮）のみ対応しています")
        return False
    
    # ALAC → WAV変換
    cmd = ["ffmpeg", "-i", m4a_path, "-acodec", "pcm_s16le", "-y", wav_path]
    result = subprocess.run(cmd, capture_output=True)
    
    if result.returncode != 0:
        print(f"   ❌ m4a変換エラー: {result.stderr[:200]}")
        return False
    
    return os.path.exists(wav_path)


def convert_any_to_lamf(src_path):
    """WAV/FLAC/m4a(ALAC)をLAMFに変換"""
    src_path = Path(src_path)
    ext = src_path.suffix.lower()
    
    lamf_name = src_path.name.replace(ext, '.lamf')
    lamf_path = Path(OUTPUT_FOLDER) / lamf_name
    
    if lamf_path.exists():
        print(f"   ⏭ スキップ（既存）: {lamf_name}")
        return False
    
    if ext == '.wav':
        print(f"   🔄 WAV → LAMF変換中...")
        wav_to_lamf(str(src_path), str(lamf_path))
        return lamf_path.exists()
    
    elif ext == '.flac':
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp_wav = tmp.name
        
        try:
            print(f"   🔄 FLAC → WAV変換中...")
            if not flac_to_wav(str(src_path), tmp_wav):
                print(f"   ❌ FLAC変換失敗")
                return False
            
            print(f"   🔄 WAV → LAMF変換中...")
            wav_to_lamf(tmp_wav, str(lamf_path))
            return lamf_path.exists()
        finally:
            try:
                os.unlink(tmp_wav)
            except:
                pass
    
    elif ext == '.m4a':
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp_wav = tmp.name
        
        try:
            print(f"   🔄 m4a(ALAC) → WAV変換中...")
            if not m4a_to_wav(str(src_path), tmp_wav):
                print(f"   ❌ m4a変換失敗（ALACのみ対応）")
                return False
            
            print(f"   🔄 WAV → LAMF変換中...")
            wav_to_lamf(tmp_wav, str(lamf_path))
            return lamf_path.exists()
        finally:
            try:
                os.unlink(tmp_wav)
            except:
                pass
    
    return False


def delete_source_file(filepath):
    try:
        os.remove(filepath)
        print(f"   🗑 削除: {Path(filepath).name}")
        return True
    except Exception as e:
        print(f"   ⚠ 削除失敗: {e}")
        return False


def scan_and_process():
    watch_path = Path(WATCH_FOLDER)
    
    source_files = []
    for ext in SUPPORTED_EXTENSIONS:
        source_files.extend(watch_path.glob(f"*{ext}"))

    if not source_files:
        return

    for src_path in source_files:
        name_key = src_path.name

        if not is_file_ready(str(src_path)):
            print(f"⏳ 書き込み中... {src_path.name}")
            continue

        file_hash = get_file_hash(str(src_path))
        if file_hash and file_hash in processed_hashes:
            continue
        if name_key in processed_names:
            continue

        print(f"\n📁 検出: {src_path.name} (拡張子: {src_path.suffix})")

        if convert_any_to_lamf(str(src_path)):
            if delete_source_file(str(src_path)):
                if file_hash:
                    processed_hashes.add(file_hash)
                processed_names.add(name_key)
        else:
            print(f"   ⚠ 変換失敗のため元ファイルを残します: {src_path.name}")


def print_header():
    print("""
    ╔════════════════════════════════════════════════════════════════╗
    ║                                                                ║
    ║     ██╗      █████╗ ███╗   ███╗███████╗                        ║
    ║     ██║     ██╔══██╗████╗ ████║██╔════╝                        ║
    ║     ██║     ███████║██╔████╔██║█████╗                          ║
    ║     ██║     ██╔══██║██║╚██╔╝██║██╔══╝                          ║
    ║     ███████╗██║  ██║██║ ╚═╝ ██║██║                             ║
    ║     ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝                             ║
    ║                                                                ║
    ║     ██████╗ ██╗██████╗ ██████╗ ██╗███╗   ██╗ ██████╗           ║
    ║     ██╔══██╗██║██╔══██╗██╔══██╗██║████╗  ██║██╔════╝           ║
    ║     ██████╔╝██║██████╔╝██████╔╝██║██╔██╗ ██║██║  ███╗          ║
    ║     ██╔═══╝ ██║██╔═══╝ ██╔═══╝ ██║██║╚██╗██║██║   ██║          ║
    ║     ██║     ██║██║     ██║     ██║██║ ╚████║╚██████╔╝          ║
    ║     ╚═╝     ╚═╝╚═╝     ╚═╝     ╚═╝╚═╝  ╚═══╝ ╚═════╝           ║
    ║                                                                ║
    ╠════════════════════════════════════════════════════════════════╣
    ║     自動変換ウォッチャー v1.0 (WAV/FLAC/m4a-ALAC対応)          ║
    ╚════════════════════════════════════════════════════════════════╝
    """)


def main():
    print_header()
    print(f"\n  📁 監視中: {WATCH_FOLDER}")
    print(f"  📁 出力先: {OUTPUT_FOLDER}")
    print(f"  📄 対応形式: WAV, FLAC, m4a（ALACコーデックのみ）")
    print(f"\n  ⏳ 監視開始... (Ctrl+C で終了)\n")

    try:
        while True:
            scan_and_process()
            time.sleep(SLEEP_INTERVAL)
    except KeyboardInterrupt:
        print("\n\n  👋 終了しました")
    except Exception as e:
        print(f"\n  ❌ エラー: {e}")
        input("  Enterキーで終了...")


if __name__ == "__main__":
    main()
