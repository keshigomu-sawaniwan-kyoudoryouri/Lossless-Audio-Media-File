"""
.lamf 変換ツール
WAV → LAMF 変換（無圧縮PCM）
LAMF Format v1.0 準拠
"""

import struct
import sys
import os
from pathlib import Path
import zlib

def wav_to_lamf(wav_path: str, lamf_path: str = None) -> str:
    """
    WAVファイルをLAMFフォーマットに変換する
    """
    if lamf_path is None:
        lamf_path = str(Path(wav_path).with_suffix('.lamf'))
    
    # 1. WAV読み込み
    with open(wav_path, 'rb') as f:
        riff = f.read(4)
        if riff != b'RIFF':
            raise ValueError("Not a valid WAV file")
        
        f.read(4)
        wave = f.read(4)
        if wave != b'WAVE':
            raise ValueError("Not a valid WAV file")
        
        sample_rate = None
        bit_depth = None
        channels = None
        num_samples = None
        pcm_data = None
        
        while True:
            chunk_id = f.read(4)
            if len(chunk_id) < 4:
                break
            
            chunk_size = struct.unpack('<I', f.read(4))[0]
            
            if chunk_id == b'fmt ':
                audio_format = struct.unpack('<H', f.read(2))[0]
                channels = struct.unpack('<H', f.read(2))[0]
                sample_rate = struct.unpack('<I', f.read(4))[0]
                f.read(4)  # byte_rate
                f.read(2)  # block_align
                bit_depth = struct.unpack('<H', f.read(2))[0]
                
                f.read(chunk_size - 16)
                
                if audio_format != 1:
                    raise ValueError(f"Unsupported audio format: {audio_format} (only PCM)")
                
            elif chunk_id == b'data':
                pcm_data = f.read(chunk_size)
                bytes_per_sample = bit_depth // 8
                num_samples = len(pcm_data) // (bytes_per_sample * channels)
                break
            else:
                f.read(chunk_size)
    
    if pcm_data is None:
        raise ValueError("No data chunk found in WAV file")
    
    if bit_depth not in (16, 24):
        raise ValueError(f"Unsupported bit depth: {bit_depth}")
    
    if channels not in (1, 2):
        raise ValueError(f"Unsupported channels: {channels}")
    
    # 2. LAMFヘッダ作成
    magic = b'LAMF'
    version = 0x0100
    header_size = 32
    data_size = len(pcm_data)
    option_offset = 0
    
    # 正しい順序でpack（フォーマット文字列のスペースは無視される）
    # フォーマット: <4s H H I H H I I I I
    header_without_crc = struct.pack(
        '<4sHHIHHIII',
        magic,           # 4s
        version,         # H
        header_size,     # H
        sample_rate,     # I
        bit_depth,       # H
        channels,        # H
        num_samples,     # I
        data_size,       # I
        option_offset,   # I
    )
    
    # CRC32計算（4バイト分の空きを作ってから）
    crc32 = zlib.crc32(header_without_crc) & 0xFFFFFFFF
    
    # CRCを含めた完全なヘッダ
    header = struct.pack(
        '<4sHHIHHIIII',
        magic,
        version,
        header_size,
        sample_rate,
        bit_depth,
        channels,
        num_samples,
        data_size,
        option_offset,
        crc32
    )
    
    # 3. 書き出し
    with open(lamf_path, 'wb') as f:
        f.write(header)
        f.write(pcm_data)
    
    print(f"✅ Converted: {wav_path} → {lamf_path}")
    print(f"   Format: {sample_rate}Hz / {bit_depth}bit / {channels}ch")
    print(f"   Samples: {num_samples:,} ({num_samples/sample_rate:.2f} sec)")
    print(f"   File size: {os.path.getsize(lamf_path):,} bytes")
    
    return lamf_path


def lamf_to_wav(lamf_path: str, wav_path: str = None) -> str:
    """LAMF → WAV変換"""
    if wav_path is None:
        wav_path = str(Path(lamf_path).with_suffix('.wav'))
    
    with open(lamf_path, 'rb') as f:
        magic = f.read(4)
        if magic != b'LAMF':
            raise ValueError("Not a valid LAMF file")
        
        version = struct.unpack('<H', f.read(2))[0]
        header_size = struct.unpack('<H', f.read(2))[0]
        sample_rate = struct.unpack('<I', f.read(4))[0]
        bit_depth = struct.unpack('<H', f.read(2))[0]
        channels = struct.unpack('<H', f.read(2))[0]
        num_samples = struct.unpack('<I', f.read(4))[0]
        data_size = struct.unpack('<I', f.read(4))[0]
        option_offset = struct.unpack('<I', f.read(4))[0]
        stored_crc = struct.unpack('<I', f.read(4))[0]
        
        # ヘッダCRC検証
        f.seek(0)
        header_data = f.read(32)
        header_for_crc = header_data[:28] + b'\x00\x00\x00\x00'  # CRC部分をゼロに
        calc_crc = zlib.crc32(header_for_crc) & 0xFFFFFFFF
        
        if calc_crc != stored_crc:
            print(f"⚠ Warning: CRC mismatch")
        
        # PCMデータ読み込み
        pcm_data = f.read(data_size)
    
    # WAV書き出し
    bytes_per_sample = bit_depth // 8
    data_chunk_size = len(pcm_data)
    file_size = 36 + data_chunk_size
    
    with open(wav_path, 'wb') as f:
        f.write(b'RIFF')
        f.write(struct.pack('<I', file_size))
        f.write(b'WAVE')
        f.write(b'fmt ')
        f.write(struct.pack('<I', 16))
        f.write(struct.pack('<H', 1))
        f.write(struct.pack('<H', channels))
        f.write(struct.pack('<I', sample_rate))
        f.write(struct.pack('<I', sample_rate * channels * bytes_per_sample))
        f.write(struct.pack('<H', channels * bytes_per_sample))
        f.write(struct.pack('<H', bit_depth))
        f.write(b'data')
        f.write(struct.pack('<I', data_chunk_size))
        f.write(pcm_data)
    
    print(f"✅ Converted: {lamf_path} → {wav_path}")
    return wav_path


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python convert.py input.wav            → to .lamf")
        print("  python convert.py input.lamf --to-wav → to .wav")
        sys.exit(1)
    
    input_path = sys.argv[1]
    
    if input_path.lower().endswith('.wav'):
        wav_to_lamf(input_path)
    elif input_path.lower().endswith('.lamf') and len(sys.argv) > 2 and sys.argv[2] == '--to-wav':
        lamf_to_wav(input_path)
    else:
        print(f"Unknown file type: {input_path}")
