"""
player.py - LAMF CLIプレーヤー（フォルダ選択方式）
"""

import struct
import sys
import time
import threading
from pathlib import Path

import numpy as np
import sounddevice as sd
import keyboard
import ctypes
import ctypes.wintypes
import tkinter as tk
from tkinter import filedialog


# ========== アクティブウィンドウ判定 ==========
user32 = ctypes.windll.user32

def get_foreground_window_title():
    hwnd = user32.GetForegroundWindow()
    length = user32.GetWindowTextLengthW(hwnd)
    buff = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buff, length + 1)
    return buff.value

def is_lamf_window_active():
    current_title = get_foreground_window_title().lower()
    return any(x in current_title for x in ["lamf", "player", "python", "exe"])


def select_folder():
    """フォルダ選択ダイアログを表示"""
    root = tk.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    folder = filedialog.askdirectory(title="LAMFファイルがあるフォルダを選択")
    root.destroy()
    return folder


def find_lamf_files(folder):
    """フォルダ内の全LAMFファイルを再帰的に取得してソート"""
    path = Path(folder)
    files = list(path.rglob("*.lamf"))
    # ファイル名でソート（自然順）
    files.sort(key=lambda x: x.name)
    return [str(f) for f in files]


def load_lamf(filepath):
    with open(filepath, 'rb') as f:
        if f.read(4) != b'LAMF':
            raise ValueError("Not a valid LAMF file")

        f.read(2)
        f.read(2)
        sample_rate = struct.unpack('<I', f.read(4))[0]
        bit_depth = struct.unpack('<H', f.read(2))[0]
        channels = struct.unpack('<H', f.read(2))[0]
        num_samples = struct.unpack('<I', f.read(4))[0]
        data_size = struct.unpack('<I', f.read(4))[0]
        f.read(4)
        f.read(4)

        pcm_data = f.read(data_size)

    bytes_per_sample = bit_depth // 8

    if bit_depth == 16:
        audio_int = np.frombuffer(pcm_data, dtype=np.int16)
        audio_float = audio_int.astype(np.float32) / 32768.0
    elif bit_depth == 24:
        audio_int = np.zeros(len(pcm_data) // 3, dtype=np.int32)
        for i in range(len(audio_int)):
            idx = i * 3
            sample = (pcm_data[idx] |
                      (pcm_data[idx+1] << 8) |
                      (pcm_data[idx+2] << 16))
            if sample & 0x800000:
                sample |= 0xFF000000
            audio_int[i] = sample
        audio_float = audio_int.astype(np.float32) / 8388608.0
    else:
        raise ValueError(f"Unsupported bit depth: {bit_depth}")

    if channels == 2:
        audio = audio_float.reshape(-1, 2)
    else:
        audio = audio_float.reshape(-1, 1)

    return audio, sample_rate, bit_depth, channels, num_samples


def format_time(seconds):
    mins = int(seconds // 60)
    secs = int(seconds % 60)
    return f"{mins:02d}:{secs:02d}"


class LAMFPlayer:
    def __init__(self, file_list):
        self.playlist = file_list
        self.current_index = 0
        self.audio = None
        self.sample_rate = None
        self.duration = 0
        self.current_time = 0
        self.is_playing = False
        self.is_paused = False
        self.should_exit = False
        self.progress_running = True
        self.bar_length = 40

        self.last_key_time = {}
        self.key_cooldown = 0.3
        self.seeking = False
        self.track_changing = False

        self.load_current_track()
        self.key_thread = threading.Thread(target=self.key_listener, daemon=True)
        self.key_thread.start()

    def is_key_ready(self, key_name):
        now = time.time()
        if key_name in self.last_key_time:
            if now - self.last_key_time[key_name] < self.key_cooldown:
                return False
        self.last_key_time[key_name] = now
        return True

    def load_current_track(self):
        try:
            filepath = self.playlist[self.current_index]
            print(f"\n  📂 読み込み中: {Path(filepath).name}")

            self.audio, self.sample_rate, bit_depth, channels, _ = load_lamf(filepath)
            self.duration = len(self.audio) / self.sample_rate
            self.current_time = 0
            self.seeking = False

            ch_text = "ステレオ" if channels == 2 else "モノラル"
            print(f"  📊 {self.sample_rate}Hz / {bit_depth}bit / {ch_text}")
            print(f"  ⏱  {format_time(self.duration)}")
            return True
        except Exception as e:
            print(f"  ❌ 読み込みエラー: {e}")
            return False

    def play(self):
        if self.audio is None:
            return
        self.is_playing = True
        self.is_paused = False
        self.start_time = time.time() - self.current_time

        sd.play(self.audio[int(self.current_time * self.sample_rate):], 
                self.sample_rate)

        if not hasattr(self, 'progress_thread') or not self.progress_thread.is_alive():
            self.progress_running = True
            self.progress_thread = threading.Thread(target=self.update_progress, daemon=True)
            self.progress_thread.start()

    def pause(self):
        if self.is_playing and not self.is_paused:
            self.is_paused = True
            sd.stop()

    def resume(self):
        if self.is_playing and self.is_paused:
            self.is_paused = False
            self.start_time = time.time() - self.current_time
            sd.play(self.audio[int(self.current_time * self.sample_rate):], 
                    self.sample_rate)

    def seek(self, delta_seconds):
        if self.audio is None or self.track_changing:
            return

        new_time = self.current_time + delta_seconds
        new_time = max(0, min(self.duration, new_time))

        if abs(new_time - self.current_time) < 0.1:
            return

        self.seeking = True
        self.current_time = new_time

        if self.is_playing and not self.is_paused:
            sd.stop()
            self.start_time = time.time() - self.current_time
            sd.play(self.audio[int(self.current_time * self.sample_rate):], 
                    self.sample_rate)

        threading.Timer(0.1, lambda: setattr(self, 'seeking', False)).start()

    def next_track(self):
        if self.track_changing:
            return
        
        if self.current_index + 1 < len(self.playlist):
            self.track_changing = True
            sd.stop()
            self.current_index += 1
            
            if self.load_current_track():
                self.current_time = 0
                self.seeking = False
                
                if self.is_playing:
                    self.is_playing = False
                    self.play()
            
            self.track_changing = False
        else:
            # プレイリスト終了
            print("\n  📋 プレイリストの終わりです")
            self.pause()

    def prev_track(self):
        if self.track_changing:
            return
        
        if self.current_index - 1 >= 0:
            self.track_changing = True
            sd.stop()
            self.current_index -= 1
            
            if self.load_current_track():
                self.current_time = 0
                self.seeking = False
                
                if self.is_playing:
                    self.is_playing = False
                    self.play()
            
            self.track_changing = False
        else:
            # 先頭で前の曲を押したら先頭に戻る
            self.seek(-self.current_time)

    def shutdown(self):
        self.should_exit = True
        self.progress_running = False
        self.is_playing = False
        sd.stop()
        time.sleep(0.2)

    def update_progress(self):
        while self.progress_running and not self.should_exit:
            if not self.track_changing and self.is_playing and not self.is_paused and not self.seeking:
                self.current_time = time.time() - self.start_time
                if self.current_time >= self.duration:
                    self.next_track()
                    continue

            if not self.track_changing and self.duration > 0:
                ratio = self.current_time / self.duration
                filled = int(self.bar_length * ratio)
                bar = '█' * filled + '░' * (self.bar_length - filled)
                status = "▶" if not self.is_paused else "⏸"
                sys.stdout.write(f"\r  {status} [{bar}] {format_time(self.current_time)} / {format_time(self.duration)}")
                sys.stdout.flush()

            time.sleep(0.05)

    def key_listener(self):
        while not self.should_exit:
            try:
                if not is_lamf_window_active():
                    time.sleep(0.1)
                    continue

                if keyboard.is_pressed('space') and self.is_key_ready('space'):
                    if self.is_playing and not self.is_paused:
                        self.pause()
                    elif self.is_playing and self.is_paused:
                        self.resume()
                    elif not self.is_playing:
                        self.play()
                    time.sleep(0.1)

                elif keyboard.is_pressed('right') and self.is_key_ready('right'):
                    self.seek(5)

                elif keyboard.is_pressed('left') and self.is_key_ready('left'):
                    self.seek(-5)

                elif keyboard.is_pressed('up') and self.is_key_ready('up'):
                    self.next_track()

                elif keyboard.is_pressed('down') and self.is_key_ready('down'):
                    self.prev_track()

                elif keyboard.is_pressed('q') and self.is_key_ready('q'):
                    self.shutdown()
                    break

                time.sleep(0.05)
            except:
                pass

    def run(self):
        self.play()

        try:
            while not self.should_exit:
                if not self.is_playing and not self.is_paused and not self.track_changing:
                    time.sleep(0.1)
                else:
                    time.sleep(0.1)
            self.cleanup()
        except KeyboardInterrupt:
            self.cleanup()

    def cleanup(self):
        self.shutdown()
        print("\n\n  ✨ ご利用ありがとうございました ✨")


def print_header():
    print(r"""
    ╔══════════════════════════════════════════════════════════════════╗
    ║                                                                  ║
    ║     ██╗      █████╗ ███╗   ███╗███████╗                         ║
    ║     ██║     ██╔══██╗████╗ ████║██╔════╝                         ║
    ║     ██║     ███████║██╔████╔██║█████╗                           ║
    ║     ██║     ██╔══██║██║╚██╔╝██║██╔══╝                           ║
    ║     ███████╗██║  ██║██║ ╚═╝ ██║██║                              ║
    ║     ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝                              ║
    ║                                                                  ║
    ║     ██████╗ ██╗      █████╗ ██╗   ██╗███████╗██████╗             ║
    ║     ██╔══██╗██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗            ║
    ║     ██████╔╝██║     ███████║ ╚████╔╝ █████╗  ██████╔╝            ║
    ║     ██╔═══╝ ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗            ║
    ║     ██║     ███████╗██║  ██║   ██║   ███████╗██║  ██║            ║
    ║     ╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝            ║
    ║                                                                  ║
    ╠══════════════════════════════════════════════════════════════════╣
    ║   Space:再生/一時停止  →:5秒スキップ  ←:5秒巻き戻し            ║
    ║   ↑:次の曲  ↓:前の曲  q:終了                                    ║
    ║   ※ このウィンドウがアクティブなときだけ操作可能               ║
    ╚══════════════════════════════════════════════════════════════════╝
    """)


def main():
    print_header()

    # コマンドライン引数があればファイルとして処理、なければフォルダ選択
    if len(sys.argv) >= 2:
        # 従来通り：ファイル指定で起動
        playlist = [str(Path(f).resolve()) for f in sys.argv[1:]]
    else:
        # フォルダ選択ダイアログを表示
        print("\n  📁 フォルダを選択してください...")
        folder = select_folder()
        if not folder:
            print("  ❌ キャンセルされました")
            input("\n  Enterキーで終了...")
            sys.exit(1)
        
        playlist = find_lamf_files(folder)
        if not playlist:
            print(f"  ❌ 選択したフォルダにLAMFファイルが見つかりません: {folder}")
            input("\n  Enterキーで終了...")
            sys.exit(1)
        
        print(f"\n  📁 フォルダ: {folder}")
        print(f"  📋 {len(playlist)}個のLAMFファイルを検出")

    player = LAMFPlayer(playlist)
    player.run()


if __name__ == "__main__":
    main()
